package com.vnatures.hospital;

public class Nurse implements Visitor {

	private String name;
	private int age;
	private String school;
	private int dob;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public int getDob() {
		return dob;
	}
	public void setDob(int dob) {
		this.dob = dob;
	}
	@Override
	public String visit(Visitable visitabel) {
			return "Nurse visiting a pateint";
		
	}
	@Override
	public String visit(Emergency emergency) {
		return "Nurse visiting Emergency petient";
	}
	@Override
	public String visit(NonEmergency nonEmergency) {

		return "Nurese visiting nonemergency peteint";
	}

}
