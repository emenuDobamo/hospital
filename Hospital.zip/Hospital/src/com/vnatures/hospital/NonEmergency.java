package com.vnatures.hospital;

public class NonEmergency extends peteint implements Visitable{

	public NonEmergency(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	@Override
	public String accept(Visitor visitor){
		
		return visitor.visit(this);
	}

}
