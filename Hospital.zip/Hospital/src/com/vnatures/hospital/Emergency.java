package com.vnatures.hospital;

public class Emergency extends peteint implements Visitable{

	public Emergency(String name) {
		super(name);

	}
	@Override 
	public String accept(Visitor visitor){
		
		return visitor.visit(this);
	}

}
