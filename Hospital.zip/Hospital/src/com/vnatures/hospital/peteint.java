package com.vnatures.hospital;

public class peteint implements Visitable {
	private String name;
	private int insurance;
	private int age;
	private String [] alergis;
	private String[] symptoms;
	private String emergencyContact;
	private int socialSecurity;
	private int birthdate;
	private int roomNum;
	private int dob;
	private peteint next;
	
	
	public peteint(String name){
		
		this.name= name;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public int getInsurance() {
		return insurance;
	}
	public void setInsurance(int insurance) {
		this.insurance = insurance;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String[] getAlergis() {
		return alergis;
	}
	public void setAlergis(String[] alergis) {
		this.alergis = alergis;
	}
	public String[] getSymptoms() {
		return symptoms;
	}
	public void setSymptoms(String[] symptoms) {
		this.symptoms = symptoms;
	}
	public String getEmergencyContact() {
		return emergencyContact;
	}
	public void setEmergencyContact(String emergencyContact) {
		this.emergencyContact = emergencyContact;
	}
	public int getSocialSecurity() {
		return socialSecurity;
	}
	public void setSocialSecurity(int socialSecurity) {
		this.socialSecurity = socialSecurity;
	}
	public int getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(int birthdate) {
		this.birthdate = birthdate;
	}
	public int getRoomNum() {
		return roomNum;
	}
	public void setRoomNum(int roomNum) {
		this.roomNum = roomNum;
	}
	
	@Override
	public String accept(Visitor visitor) {
		return visitor.visit(this);
		
	}


	public int getDob() {
		return dob;
	}


	public void setDob(int dob) {
		this.dob = dob;
	}


	public peteint getNext() {
		return next;
	}


	public void setNext(peteint next) {
		this.next = next;
	}


	

}
