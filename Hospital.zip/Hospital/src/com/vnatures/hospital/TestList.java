package com.vnatures.hospital;

public class TestList {
public static void main (String [] args){
	
	peteint emenu = new peteint("emenu");
LinkedList today = new LinkedList();
today.add(emenu);
System.out.println(today);
}
}
