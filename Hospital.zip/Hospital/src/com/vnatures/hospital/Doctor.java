package com.vnatures.hospital;

public class Doctor implements Visitor{

	private String name;
	private int socialSecurity;
	private String speciality;
	private int age;
	private int dob;
	private Doctor next;	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSocialSecurity() {
		return socialSecurity;
	}

	public void setSocialSecurity(int socialSecurity) {
		this.socialSecurity = socialSecurity;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String visit(Visitable visitabel) {
			return "Doctor visiting a pateint";
		
	}
	@Override
	public String visit(Emergency emergency) {
		return "Doctor visiting Emergency petient";
	}
	@Override
	public String visit(NonEmergency nonEmergency) {

		return "Doctor visiting NonEmergency petient";
	}

	public Doctor getNext() {
		return next;
	}

	public void setNext(Doctor next) {
		this.next = next;
	}

	public int getDob() {
		return dob;
	}

	public void setDob(int dob) {
		this.dob = dob;
	}

}
