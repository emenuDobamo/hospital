package com.vnatures.hospital;

public interface Visitor {
	
	public String visit(Visitable visitabel);
	public String visit (Emergency emergency);
	public String visit (NonEmergency nonEmergency);

}
