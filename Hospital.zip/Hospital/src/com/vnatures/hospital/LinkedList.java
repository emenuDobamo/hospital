package com.vnatures.hospital;

public class LinkedList<E> {
	
int size =0;

Node<E> first;
Node<E> last;
public  void linkFirst(E e){
	
	if(first == null){
		
		first = Node<e>;
	}
	
	Node<E> f = first;
	Node<E> newNode = new Node<E>(null, e,f);
	first = newNode;
	if (f == null)
    last = newNode;
else
    f.prev = newNode;
size++;
	
	
}


@Override
public String toString(){
	
	return "";
}

}
class Node<E>{
	E item;
	Node<E> next;
	Node<E> prev;
	
	Node (Node<E> prev, E element , Node<E> next){
		this.item = element;
		this.next = next;
		this.prev= prev;
	}
	
	
}