package com.vnatures.hospital;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class main extends Application{


	@Override
	public void start(Stage primaryStage) throws Exception {

	
	}
	
	public static void main (String [] args){
		
		Doctor emenu = new Doctor ();
		Nurse aster =new Nurse();
		NonEmergency henock = new NonEmergency("henok");
		Emergency neamen = new Emergency("emenu");
		System.out.println(neamen.accept(emenu));
		System.out.println(neamen.accept(aster));
		System.out.println(henock.accept(aster));
		System.out.println(henock.accept(emenu));
		
		launch();
	}

}
