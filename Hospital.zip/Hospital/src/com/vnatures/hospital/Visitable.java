package com.vnatures.hospital;

public interface Visitable {
	
	public String accept(Visitor visitor);
	
}
